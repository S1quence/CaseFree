from django.contrib import admin
from django.urls import include, path
from django.views.generic import TemplateView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path("", TemplateView.as_view(template_name="home.html"), name="home"),
    path("admin/", admin.site.urls),
    path("api/accounts/", include("apps.accounts.api_urls")),
    path("api/", include("apps.catalog.urls")),
    path("api/", include("apps.clients.urls")),
    path("api/", include("apps.orders.urls")),
    path("api/reports/", include("apps.reports.urls")),
    path("api/auth/login/", TokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("api/auth/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("", include("apps.accounts.urls")),
]
