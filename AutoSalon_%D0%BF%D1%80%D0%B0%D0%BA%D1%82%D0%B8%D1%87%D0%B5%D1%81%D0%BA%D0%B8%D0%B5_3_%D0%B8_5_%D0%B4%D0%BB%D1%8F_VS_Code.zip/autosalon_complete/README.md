# AutoSalon — практические работы №3 и №5

Учебная информационная система автосалона. Практическая №3: настройка среды Windows, Django, PostgreSQL и Memurai/Redis. Практическая №5: пять модулей `accounts`, `catalog`, `clients`, `orders`, `reports`, REST API и Streamlit-дашборд.

## 1. Открытие в Visual Studio Code
1. Распакуйте архив в удобную папку, например `C:\study\AutoSalon`.
2. Откройте VS Code → **File → Open Folder** → выберите `AutoSalon`.
3. Откройте **Terminal → New Terminal** (PowerShell).

## 2. Виртуальное окружение и библиотеки
```powershell
python --version
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```
Если PowerShell запрещает активацию, выполните в текущем окне:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## 3. PostgreSQL и Memurai
Создайте в PostgreSQL базу `autosalon` (через pgAdmin или `psql`). Скопируйте `.env.example` в `.env` и укажите пароль PostgreSQL и собственный `SECRET_KEY`.
Установите Memurai Developer, если он требуется по методичке; служба должна слушать порт `6379`. Для включения Redis-кеша оставьте `REDIS_URL=redis://127.0.0.1:6379/1` в `.env`. Если Memurai пока не установлен, удалите или оставьте пустым значение `REDIS_URL` — приложение использует локальный кеш.

## 4. Миграции и запуск
```powershell
python manage.py check
python manage.py makemigrations accounts catalog clients orders
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
Откройте `http://127.0.0.1:8000/` и `http://127.0.0.1:8000/admin/`.

## 5. Проверка API
- `GET /api/` — корень каталога API (маршруты модулей доступны отдельно).
- `GET /api/cars/` — автомобили.
- `GET /api/clients/` — клиенты (нужна авторизация).
- `GET /api/orders/` — заказы (нужна авторизация).
- `GET /api/accounts/users/` — сотрудники (только администратор).
- `GET /api/reports/kpi/` — KPI (нужна авторизация).
- `POST /api/auth/login/` — получить JWT: `{"username":"...","password":"..."}`.
- `POST /api/auth/refresh/` — обновить access-токен.

Для защищённых запросов передавайте заголовок `Authorization: Bearer ACCESS_TOKEN`.

## 6. Тесты и Streamlit
```powershell
python manage.py test
streamlit run dashboard/app.py
```

## Структура
- `config/` — настройки и главная маршрутизация Django.
- `apps/accounts/` — сотрудники, роли, авторизация и сериализатор.
- `apps/catalog/` — марки, автомобили и справочники Location, Category, Vendor, Model.
- `apps/clients/` — клиенты.
- `apps/orders/` — заказы и изменение статусов автомобилей.
- `apps/reports/` — KPI.
- `dashboard/` — Streamlit-панель.
- `docs/` — отчёт, руководства, инструкции и презентация.
