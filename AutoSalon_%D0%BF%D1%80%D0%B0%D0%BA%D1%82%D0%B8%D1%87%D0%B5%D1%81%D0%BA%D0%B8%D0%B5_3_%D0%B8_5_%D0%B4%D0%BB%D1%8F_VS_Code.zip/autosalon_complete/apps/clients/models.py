from django.db import models
class Client(models.Model):
    first_name = models.CharField("Имя", max_length=80)
    last_name = models.CharField("Фамилия", max_length=80)
    phone = models.CharField("Телефон", max_length=30, unique=True)
    email = models.EmailField("Электронная почта", blank=True)
    notes = models.TextField("Примечание", blank=True)
    created_at = models.DateTimeField("Дата добавления", auto_now_add=True)
    def __str__(self): return f"{self.last_name} {self.first_name}"
    class Meta: verbose_name = "Клиент"; verbose_name_plural = "Клиенты"; ordering = ["last_name"]
