from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    ROLE_CHOICES = [("manager", "Менеджер"), ("admin", "Администратор"), ("director", "Руководитель")]
    role = models.CharField("Роль", max_length=20, choices=ROLE_CHOICES, default="manager")
    phone = models.CharField("Телефон", max_length=30, blank=True)
    def __str__(self):
        return self.get_full_name() or self.username
