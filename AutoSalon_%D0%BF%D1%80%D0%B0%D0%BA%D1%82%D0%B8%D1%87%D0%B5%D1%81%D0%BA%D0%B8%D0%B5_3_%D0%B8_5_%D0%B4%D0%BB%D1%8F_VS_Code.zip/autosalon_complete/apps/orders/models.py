from django.db import models
from django.conf import settings
from django.utils import timezone
from apps.catalog.models import Car
from apps.clients.models import Client

class Order(models.Model):
    STATUS = [("new", "Новый"), ("in_progress", "В работе"), ("completed", "Завершён"), ("cancelled", "Отменён")]
    TYPE = [("purchase", "Покупка"), ("test_drive", "Тест-драйв"), ("service", "Сервис")]
    client = models.ForeignKey(Client, on_delete=models.PROTECT, verbose_name="Клиент", related_name="orders")
    car = models.ForeignKey(Car, on_delete=models.PROTECT, verbose_name="Автомобиль", related_name="orders")
    manager = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, verbose_name="Менеджер")
    order_type = models.CharField("Тип заказа", max_length=20, choices=TYPE, default="purchase")
    status = models.CharField("Статус", max_length=20, choices=STATUS, default="new")
    total = models.DecimalField("Сумма", max_digits=12, decimal_places=2)
    created_at = models.DateTimeField("Создан", auto_now_add=True)
    completed_at = models.DateTimeField("Завершён", null=True, blank=True)
    def save(self, *args, **kwargs):
        if self.pk:
            old = Order.objects.filter(pk=self.pk).only("status").first()
            if old and old.status != "completed" and self.status == "completed":
                self.completed_at = timezone.now()
                if self.order_type == "purchase":
                    self.car.status = "sold"
                    self.car.save(update_fields=["status"])
        elif self.order_type == "purchase":
            # Резервируем автомобиль при создании заказа на покупку.
            self.car.status = "reserved"
            self.car.save(update_fields=["status"])
        super().save(*args, **kwargs)
    def __str__(self): return f"Заказ №{self.pk or 'новый'} — {self.client}"
    class Meta: verbose_name = "Заказ"; verbose_name_plural = "Заказы"; ordering = ["-created_at"]
