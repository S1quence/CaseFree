from django import forms
from .models import Order
class OrderForm(forms.ModelForm):
    class Meta: model = Order; fields = ["client", "car", "manager", "order_type", "status", "total"]
