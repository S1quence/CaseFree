from django.test import TestCase
from django.contrib.auth import get_user_model
from apps.catalog.models import Brand, Car
from apps.clients.models import Client
from .models import Order
class OrderFlowTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="manager", password="pass12345")
        self.brand = Brand.objects.create(name="Test")
        self.car = Car.objects.create(brand=self.brand, model="A", year=2020, vin="VIN00000000000001", price=100)
        self.client_obj = Client.objects.create(first_name="Иван", last_name="Иванов", phone="+37100000000")
    def test_purchase_reserves_car(self):
        Order.objects.create(client=self.client_obj, car=self.car, manager=self.user, total=100)
        self.car.refresh_from_db()
        self.assertEqual(self.car.status, "reserved")
