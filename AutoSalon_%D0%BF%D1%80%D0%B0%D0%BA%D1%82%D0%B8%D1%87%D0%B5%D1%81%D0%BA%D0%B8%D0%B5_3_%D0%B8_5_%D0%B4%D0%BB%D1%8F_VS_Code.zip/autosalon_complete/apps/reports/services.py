from django.db.models import Sum, Count
from apps.orders.models import Order
from apps.catalog.models import Car
def get_kpi():
    completed = Order.objects.filter(status="completed")
    return {
        "orders_total": Order.objects.count(),
        "orders_completed": completed.count(),
        "revenue": completed.aggregate(value=Sum("total"))["value"] or 0,
        "cars_available": Car.objects.filter(status="available").count(),
        "cars_reserved": Car.objects.filter(status="reserved").count(),
        "cars_sold": Car.objects.filter(status="sold").count(),
    }
