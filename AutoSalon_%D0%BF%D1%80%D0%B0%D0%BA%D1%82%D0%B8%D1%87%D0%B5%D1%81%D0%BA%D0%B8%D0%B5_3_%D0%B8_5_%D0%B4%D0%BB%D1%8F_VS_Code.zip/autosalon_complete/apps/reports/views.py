from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .services import get_kpi
@api_view(["GET"])
@permission_classes([IsAuthenticated])
def kpi(request):
    return Response(get_kpi())
