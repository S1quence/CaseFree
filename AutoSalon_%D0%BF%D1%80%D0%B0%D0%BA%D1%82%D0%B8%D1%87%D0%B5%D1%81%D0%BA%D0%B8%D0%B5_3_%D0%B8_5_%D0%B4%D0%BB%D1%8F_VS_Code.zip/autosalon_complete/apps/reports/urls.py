from django.urls import path
from .views import kpi

urlpatterns = [path("kpi/", kpi, name="kpi")]
