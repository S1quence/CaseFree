from rest_framework import viewsets, filters
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from .models import Car
from .serializers import CarSerializer
class CarViewSet(viewsets.ModelViewSet):
    queryset = Car.objects.select_related("brand").all()
    serializer_class = CarSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["model", "brand__name", "vin"]
    ordering_fields = ["price", "year", "mileage"]
