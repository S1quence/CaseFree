from django.test import TestCase
from .models import Brand, Car
class CatalogModelTests(TestCase):
    def test_car_string(self):
        brand = Brand.objects.create(name="TestBrand")
        car = Car.objects.create(brand=brand, model="Demo", year=2022, vin="TESTVIN000000001", price=10000)
        self.assertIn("Demo", str(car))
