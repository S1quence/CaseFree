from django.db import models

class Brand(models.Model):
    name = models.CharField("Марка", max_length=80, unique=True)
    country = models.CharField("Страна", max_length=80, blank=True)
    def __str__(self): return self.name
    class Meta: verbose_name = "Марка"; verbose_name_plural = "Марки"; ordering = ["name"]


class Location(models.Model):
    name = models.CharField("Название локации", max_length=120, unique=True)
    address = models.CharField("Адрес", max_length=255, blank=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Локация"
        verbose_name_plural = "Локации"


class Category(models.Model):
    name = models.CharField("Категория", max_length=100, unique=True)
    description = models.TextField("Описание", blank=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"


class Vendor(models.Model):
    name = models.CharField("Поставщик", max_length=120, unique=True)
    phone = models.CharField("Телефон", max_length=30, blank=True)
    email = models.EmailField("Электронная почта", blank=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Поставщик"
        verbose_name_plural = "Поставщики"


class Model(models.Model):
    name = models.CharField("Модель", max_length=100)
    brand = models.ForeignKey("Brand", on_delete=models.PROTECT, verbose_name="Марка")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Категория")

    def __str__(self):
        return f"{self.brand} {self.name}"

    class Meta:
        verbose_name = "Модель автомобиля"
        verbose_name_plural = "Модели автомобилей"
        unique_together = (("brand", "name"),)


class Car(models.Model):
    STATUS = [("available", "В наличии"), ("reserved", "Зарезервирован"), ("sold", "Продан")]
    brand = models.ForeignKey(Brand, on_delete=models.PROTECT, verbose_name="Марка", related_name="cars")
    model = models.CharField("Модель", max_length=100)
    year = models.PositiveSmallIntegerField("Год выпуска")
    vin = models.CharField("VIN", max_length=17, unique=True)
    price = models.DecimalField("Цена", max_digits=12, decimal_places=2)
    mileage = models.PositiveIntegerField("Пробег, км", default=0)
    color = models.CharField("Цвет", max_length=40, blank=True)
    status = models.CharField("Статус", max_length=20, choices=STATUS, default="available")
    created_at = models.DateTimeField("Добавлен", auto_now_add=True)
    def __str__(self): return f"{self.brand} {self.model} ({self.year})"
    class Meta: verbose_name = "Автомобиль"; verbose_name_plural = "Автомобили"; ordering = ["brand__name", "model"]
