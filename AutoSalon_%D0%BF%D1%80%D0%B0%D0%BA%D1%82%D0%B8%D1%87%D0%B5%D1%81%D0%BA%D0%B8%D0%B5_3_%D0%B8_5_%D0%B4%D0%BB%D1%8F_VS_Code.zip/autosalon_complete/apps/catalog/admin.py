from django.contrib import admin
from .models import Brand, Car, Category, Location, Model, Vendor


@admin.register(Brand)
class BrandAdmin(admin.ModelAdmin):
    list_display = ("name", "country")
    search_fields = ("name", "country")


@admin.register(Car)
class CarAdmin(admin.ModelAdmin):
    list_display = ("brand", "model", "year", "price", "status", "mileage")
    list_filter = ("brand", "status", "year")
    search_fields = ("model", "vin", "brand__name")
    list_editable = ("status",)


@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = ("name", "address")
    search_fields = ("name", "address")


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name",)
    search_fields = ("name",)


@admin.register(Vendor)
class VendorAdmin(admin.ModelAdmin):
    list_display = ("name", "phone", "email")
    search_fields = ("name", "phone", "email")


@admin.register(Model)
class ModelAdmin(admin.ModelAdmin):
    list_display = ("name", "brand", "category")
    list_filter = ("brand", "category")
    search_fields = ("name", "brand__name")
