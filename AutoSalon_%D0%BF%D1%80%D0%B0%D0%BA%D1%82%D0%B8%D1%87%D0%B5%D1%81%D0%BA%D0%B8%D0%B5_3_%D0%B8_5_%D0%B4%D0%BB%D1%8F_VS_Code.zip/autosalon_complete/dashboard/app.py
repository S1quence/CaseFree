import streamlit as st
import requests
st.set_page_config(page_title="AutoSalon KPI", layout="wide")
st.title("Панель показателей автосалона")
st.caption("Данные загружаются из локального Django API.")
token = st.text_input("JWT access token", type="password")
if st.button("Загрузить показатели"):
    try:
        r = requests.get("http://127.0.0.1:8000/api/reports/kpi/",
                         headers={"Authorization": f"Bearer {token}"}, timeout=5)
        r.raise_for_status()
        data = r.json()
        cols = st.columns(4)
        for col, (label, key) in zip(cols, [("Всего заказов","orders_total"),("Завершено","orders_completed"),("Выручка","revenue"),("Авто в наличии","cars_available")]):
            col.metric(label, data.get(key, 0))
        st.json(data)
    except Exception as exc:
        st.error(f"Не удалось получить данные: {exc}")
