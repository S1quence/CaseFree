using System.Windows;

namespace WorkoutTracker;

public partial class App : Application
{
}
