using System.Data;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace WorkoutTracker.Data;

public sealed class DatabaseHelper
{
    // Измените Server на имя вашего экземпляра SQL Server.
    // Для LocalDB обычно подходит: (localdb)\\MSSQLLocalDB
    private readonly string _connectionString =
        @"Server=(localdb)\MSSQLLocalDB;Database=WorkoutTrackerDB;Integrated Security=True;TrustServerCertificate=True;";

    public SqlConnection GetConnection() => new(_connectionString);

    public DataTable ExecuteQuery(string query)
    {
        var table = new DataTable();
        try
        {
            using var connection = GetConnection();
            using var adapter = new SqlDataAdapter(query, connection);
            adapter.Fill(table);
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка SQL Server ({ex.Number}): {ex.Message}",
                "Ошибка базы данных", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось выполнить запрос: {ex.Message}",
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        return table;
    }

    public int ExecuteNonQuery(string query)
    {
        try
        {
            using var connection = GetConnection();
            connection.Open();
            using var command = new SqlCommand(query, connection);
            return command.ExecuteNonQuery();
        }
        catch (SqlException ex)
        {
            MessageBox.Show($"Ошибка SQL Server ({ex.Number}): {ex.Message}",
                "Ошибка базы данных", MessageBoxButton.OK, MessageBoxImage.Error);
            return -1;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось выполнить команду: {ex.Message}",
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            return -1;
        }
    }
}
