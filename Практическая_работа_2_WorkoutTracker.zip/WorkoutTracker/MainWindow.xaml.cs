using System.Data;
using System.Windows;
using WorkoutTracker.Data;

namespace WorkoutTracker;

public partial class MainWindow : Window
{
    private readonly DatabaseHelper _dbHelper = new();

    public MainWindow()
    {
        InitializeComponent();
    }

    private void BtnLoad_Click(object sender, RoutedEventArgs e)
    {
        BtnLoad.IsEnabled = false;
        tbStatus.Text = "Загрузка упражнений...";

        try
        {
            DataTable exercises = _dbHelper.ExecuteQuery(
                "SELECT Id, Name, Category, MuscleGroup FROM dbo.Exercises ORDER BY Name;");

            dgExercises.ItemsSource = exercises.DefaultView;
            tbStatus.Text = exercises.Rows.Count > 0
                ? $"Загружено упражнений: {exercises.Rows.Count}"
                : "Записи не найдены. Проверьте таблицу dbo.Exercises в WorkoutTrackerDB.";
        }
        finally
        {
            BtnLoad.IsEnabled = true;
        }
    }
}
