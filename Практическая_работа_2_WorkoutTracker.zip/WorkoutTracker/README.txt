ПРАКТИЧЕСКАЯ РАБОТА №2 — WorkoutTracker

Что реализовано:
- WPF-приложение на .NET 8;
- класс Data/DatabaseHelper.cs;
- подключение к SQL Server через Microsoft.Data.SqlClient;
- методы GetConnection(), ExecuteQuery() и ExecuteNonQuery();
- загрузка dbo.Exercises в DataGrid;
- StatusBar с количеством загруженных строк и обработка ошибок.

ЗАПУСК:
1. Установите Visual Studio 2022 с компонентом «Разработка классических приложений .NET».
2. Убедитесь, что установлен .NET 8 SDK и запущен SQL Server/LocalDB.
3. Откройте WorkoutTracker.csproj в Visual Studio.
4. В Data/DatabaseHelper.cs измените строку подключения при необходимости:
   Server=(localdb)\MSSQLLocalDB;Database=WorkoutTrackerDB;Integrated Security=True;TrustServerCertificate=True;
   Для обычного экземпляра SQL Server замените Server на имя вашего сервера, например .\SQLEXPRESS.
5. Убедитесь, что база WorkoutTrackerDB и таблица dbo.Exercises созданы по практической работе №1,
   и что в ней есть столбцы Id, Name, Category, MuscleGroup.
6. Восстановите NuGet-пакеты (Visual Studio обычно делает это автоматически).
7. Нажмите F5, затем «Загрузить упражнения».

ОЖИДАЕМЫЙ РЕЗУЛЬТАТ:
DataGrid отображает Id, Name, Category, MuscleGroup, отсортированные по Name.
В исходном задании указано ожидание 13 записей из практической работы №1.

ВАЖНО:
В документе ПР №2 не приведены полные текстовые листинги кода на страницах с иллюстрациями,
поэтому здесь подготовлен рабочий вариант по описанным требованиям. Схема базы предполагает,
что ПР №1 создала WorkoutTrackerDB и dbo.Exercises с указанными столбцами.
