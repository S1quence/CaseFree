# Clicker — Android project

## Совместимость
- Android Gradle Plugin: 8.2.2
- Gradle: 8.2
- JDK: 17
- compileSdk / targetSdk: 34
- minSdk: 23
- Сторонних библиотек нет: проект написан на Java и использует Android SDK.

## Открытие в Android Studio
1. Распакуйте архив.
2. В Android Studio выберите **Open** и укажите папку `ClickerAndroid` (не ZIP и не папку `app`).
3. В настройках Gradle JDK выберите JDK 17.
4. Установите Android SDK Platform 34 через SDK Manager, если она ещё не установлена.
5. Дождитесь Gradle Sync и нажмите Run.

Требуется Android Studio Hedgehog (2023.1.1) или новее для поддержки Android Gradle Plugin 8.2.2.
