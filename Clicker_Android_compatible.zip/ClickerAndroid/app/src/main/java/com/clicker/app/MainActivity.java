package com.clicker.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import java.util.Locale;

public class MainActivity extends Activity {
    ClickerView view;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(57,130,212)); getWindow().setNavigationBarColor(Color.rgb(57,130,212)); view=new ClickerView(this); setContentView(view); }
    @Override protected void onPause(){ super.onPause(); if(view!=null)view.save(); }
}

class ClickerView extends View {
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); Paint text=new Paint(Paint.ANTI_ALIAS_FLAG);
    Bitmap bg, clickIcon, cartIcon, backIcon, pink;
    SharedPreferences sp; Handler handler=new Handler();
    long coins; int clickPower, clickLevel, autoLevel; float autoPerSec, clickCost, autoCost; long clicks;
    int screen=0; float objectScale=1f; boolean pressed=false;
    final int BLUE=Color.rgb(57,130,212), BTN=Color.rgb(24,91,232), WHITE=Color.WHITE, DARK=Color.rgb(25,25,25), PINK=Color.rgb(249,242,243);
    Runnable income=()->{ if(screen==0 && autoPerSec>0){ coins+=Math.round(autoPerSec); save(); invalidate(); } handler.postDelayed(income,1000); };
    ClickerView(Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); sp=c.getSharedPreferences("clicker",Context.MODE_PRIVATE); load(); bg=load(c, "background"); clickIcon=load(c,"click_icon"); cartIcon=load(c,"cart"); backIcon=load(c,"back"); pink=load(c,"pink_circle"); handler.postDelayed(income,1000); }
    Bitmap load(Context c,String n){ int id=c.getResources().getIdentifier(n,"drawable",c.getPackageName()); return BitmapFactory.decodeResource(c.getResources(),id); }
    void load(){ coins=sp.getLong("coins",0); clickPower=sp.getInt("power",1); clickLevel=sp.getInt("clickLevel",0); autoLevel=sp.getInt("autoLevel",0); autoPerSec=sp.getFloat("autoPerSec",0); clickCost=sp.getFloat("clickCost",25); autoCost=sp.getFloat("autoCost",100); clicks=sp.getLong("clicks",0); }
    void save(){ sp.edit().putLong("coins",coins).putInt("power",clickPower).putInt("clickLevel",clickLevel).putInt("autoLevel",autoLevel).putFloat("autoPerSec",autoPerSec).putFloat("clickCost",clickCost).putFloat("autoCost",autoCost).putLong("clicks",clicks).apply(); }
    protected void onDraw(Canvas c){ super.onDraw(c); if(screen==0) drawMain(c); else if(screen==1) drawShop(c); else drawQuests(c); }
    void background(Canvas c){ p.setColor(BLUE); c.drawRect(0,0,getWidth(),getHeight(),p); if(bg!=null)c.drawBitmap(bg,null,new Rect(0,0,getWidth(),getHeight()),p); }
    void drawMain(Canvas c){ background(c); int w=getWidth(),h=getHeight();
        // currency
        p.setColor(WHITE); p.setStyle(Paint.Style.FILL); c.drawRoundRect(24,24, w-24,82,22,22,p);
        text.setColor(DARK); text.setTextSize(26); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextAlign(Paint.Align.CENTER); c.drawText("💰  "+format(coins),w/2,62,text);
        float r=Math.min(w,h)*.22f; float cx=w/2f, cy=h*.40f;
        p.setColor(PINK); c.drawCircle(cx,cy,r,p);
        c.save(); c.scale(objectScale,objectScale,cx,cy); if(clickIcon!=null){ RectF dst=new RectF(cx-r*.62f,cy-r*.62f,cx+r*.62f,cy+r*.62f); c.drawBitmap(clickIcon,null,dst,p); } c.restore();
        text.setColor(WHITE); text.setTextSize(19); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); c.drawText("+"+clickPower+" за клик",cx,cy+r+36,text);
        drawButton(c,24,h-128,w/2-10,h-24,"МАГАЗИН",cartIcon);
        drawPuzzleButton(c,w/2+10,h-128,w-24,h-24,"КВЕСТЫ");
        text.setTextSize(16); text.setColor(WHITE); text.setTypeface(Typeface.DEFAULT); c.drawText("Автодоход: "+format(autoPerSec)+" / сек",cx,h-145,text);
    }
    String format(double n){ if(n>=1000000)return String.format(Locale.US,"%.1fM",n/1000000); if(n>=1000)return String.format(Locale.US,"%.1fK",n/1000); return String.valueOf((long)n); }
    void drawButton(Canvas c,float l,float t,float r,float b,String label,Bitmap icon){ p.setColor(BTN); c.drawRoundRect(l,t,r,b,10,10,p); if(icon!=null)c.drawBitmap(icon,null,new RectF(l+12,t+14,l+70,t+72),p); text.setColor(WHITE); text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(Math.min(28,getWidth()/14f)); c.drawText(label,(l+r)/2+25,(t+b)/2+10,text); }
    void drawPuzzleButton(Canvas c,float l,float t,float r,float b,String label){ p.setColor(BTN); c.drawRoundRect(l,t,r,b,10,10,p); drawPuzzle(c,l+45,(t+b)/2,32,WHITE); text.setColor(WHITE); text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(Math.min(28,getWidth()/14f)); c.drawText(label,(l+r)/2+20,(t+b)/2+10,text); }
    void drawPuzzle(Canvas c,float x,float y,float s,int color){ p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(x-s,y-s,x+s,y+s,8,8,p); c.drawCircle(x,y-s,s*.38f,p); c.drawCircle(x-s,y,s*.38f,p); c.drawCircle(x+s,y,s*.38f,p); p.setColor(BTN); c.drawCircle(x,y+s,s*.38f,p); }
    void drawHeader(Canvas c,String title){ background(c); text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setColor(WHITE); text.setTextSize(34); c.drawText(title,getWidth()/2,60,text); if(backIcon!=null)c.drawBitmap(backIcon,null,new RectF(18,18,78,78),p); }
    void drawShop(Canvas c){ drawHeader(c,"МАГАЗИН"); int w=getWidth();
        text.setTextSize(21); text.setColor(WHITE); text.setTextAlign(Paint.Align.CENTER); c.drawText("Монеты: "+format(coins),w/2,105,text);
        shopCard(c,25,135,w-25,275,"Клик-апгрейд","+1 к монетам за клик",clickCost,clickLevel,0);
        shopCard(c,25,300,w-25,440,"Авто-клик","+5 монет каждую секунду",autoCost,autoLevel,1);
        text.setTextSize(15); text.setColor(WHITE); c.drawText("Цена следующего уровня растёт ×1.5",w/2,485,text);
        drawBack(c); }
    void shopCard(Canvas c,float l,float t,float r,float b,String title,String desc,float cost,int level,int type){ p.setColor(Color.WHITE); c.drawRoundRect(l,t,r,b,20,20,p); text.setTextAlign(Paint.Align.LEFT); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(23); text.setColor(DARK); c.drawText(title,l+20,t+38,text); text.setTypeface(Typeface.DEFAULT); text.setTextSize(16); c.drawText(desc,l+20,t+66,text); c.drawText("Уровень: "+level,l+20,t+94,text); p.setColor(BTN); c.drawRoundRect(l+20,t+105,r-20,b-15,14,14,p); text.setTextAlign(Paint.Align.CENTER); text.setColor(WHITE); text.setTypeface(Typeface.DEFAULT_BOLD); text.setTextSize(19); c.drawText("КУПИТЬ  •  "+format(cost), (l+r)/2,b-35,text); }
    void drawQuests(Canvas c){ drawHeader(c,"КВЕСТЫ"); int w=getWidth(); text.setTextAlign(Paint.Align.CENTER); text.setColor(WHITE); text.setTextSize(18); c.drawText("Выполнено: "+questCompleted()+" / 3",w/2,100,text);
        quest(c,25,125,w-25,250,"Сделай 100 кликов",Math.min(clicks,100),100,20,0);
        quest(c,25,275,w-25,400,"Собери 500 монет",Math.min(coins,500),500,50,1);
        quest(c,25,425,w-25,550,"Купи первое улучшение",Math.min(clickLevel+autoLevel,1),1,75,2);
        drawBack(c); }
    int questCompleted(){int n=0; if(clicks>=100)n++; if(coins>=500)n++; if(clickLevel+autoLevel>=1)n++; return n;}
    void quest(Canvas c,float l,float t,float r,float b,String title,long val,long max,int reward,int id){ p.setColor(Color.WHITE); c.drawRoundRect(l,t,r,b,18,18,p); text.setTextAlign(Paint.Align.LEFT); text.setColor(DARK); text.setTypeface(Typeface.DEFAULT_BOLD); text.setTextSize(19); c.drawText(title,l+18,t+32,text); text.setTypeface(Typeface.DEFAULT); text.setTextSize(15); c.drawText(val+" / "+max+"  ("+(max==0?0:(val*100/max))+"%)",l+18,t+58,text); p.setColor(Color.LTGRAY); c.drawRoundRect(l+18,t+72,r-18,t+86,7,7,p); p.setColor(BTN); c.drawRoundRect(l+18,t+72,l+18+(r-l-36)*Math.min(1f,(float)val/max),t+86,7,7,p); text.setTextAlign(Paint.Align.RIGHT); text.setTextSize(14); c.drawText("Награда: +"+reward,l+18+(r-l-36),t+112,text); }
    void drawBack(Canvas c){ if(backIcon!=null)c.drawBitmap(backIcon,null,new RectF(18,getHeight()-78,78,getHeight()-18),p); else {text.setColor(WHITE);text.setTextSize(30);c.drawText("←",48,getHeight()-35,text);} }
    public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()==MotionEvent.ACTION_DOWN){ float x=e.getX(),y=e.getY(); if(screen==0){ if(y>getHeight()-150){ if(x<getWidth()/2){screen=1;invalidate();return true;} else {screen=2;invalidate();return true;} } float cx=getWidth()/2f,cy=getHeight()*.40f,r=Math.min(getWidth(),getHeight())*.27f; if(Math.hypot(x-cx,y-cy)<r){coins+=clickPower; clicks++; pressed=true; objectScale=.90f; save(); invalidate(); postDelayed(()->{objectScale=1f;pressed=false;invalidate();},90); return true;} }
            else if(screen==1){ if(y<100 && x<100){screen=0;invalidate();return true;} if(y>=135&&y<=275){buyClick();return true;} if(y>=300&&y<=440){buyAuto();return true;} }
            else { if(y<100&&x<100){screen=0;invalidate();return true;} }
        } return true; }
    void buyClick(){ if(coins>=clickCost){coins-=Math.round(clickCost);clickLevel++;clickPower++;clickCost*=1.5f;save();invalidate();} }
    void buyAuto(){ if(coins>=autoCost){coins-=Math.round(autoCost);autoLevel++;autoPerSec+=5;autoCost*=1.5f;save();invalidate();} }
}
