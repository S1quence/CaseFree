package com.example.fishingempire

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class GameScreen {
    HOME, FISHING, INVENTORY, SHOP, LOCATIONS, COLLECTION
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                FishingEmpireApp()
            }
        }
    }
}

@Composable
private fun FishingEmpireApp() {
    var screen by remember { mutableStateOf(GameScreen.HOME) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        when (screen) {
            GameScreen.HOME -> HomeScreen(onNavigate = { screen = it })
            GameScreen.FISHING -> SimpleScreen(
                "Рыбалка",
                "Здесь появятся водоём, удочка, заброс и поклёвки."
            ) { screen = GameScreen.HOME }
            GameScreen.INVENTORY -> SimpleScreen(
                "Инвентарь",
                "Здесь будут храниться твои удочки, наживки и улов."
            ) { screen = GameScreen.HOME }
            GameScreen.SHOP -> SimpleScreen(
                "Магазин",
                "Здесь можно будет покупать снасти и наживки."
            ) { screen = GameScreen.HOME }
            GameScreen.LOCATIONS -> SimpleScreen(
                "Водоёмы",
                "Здесь появится карта доступных мест для рыбалки."
            ) { screen = GameScreen.HOME }
            GameScreen.COLLECTION -> SimpleScreen(
                "Коллекция рыб",
                "Здесь будет список всех пойманных видов рыб."
            ) { screen = GameScreen.HOME }
        }
    }
}

@Composable
private fun HomeScreen(onNavigate: (GameScreen) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text("🎣", fontSize = 58.sp)
        Text(
            "РЫБАЦКАЯ ИМПЕРИЯ",
            fontSize = 25.sp,
            fontWeight = FontWeight.Bold
        )
        Text("Твоя история начинается здесь")
        HorizontalDivider()

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Уровень: 1", fontWeight = FontWeight.SemiBold)
                Text("Опыт: 0 / 100")
                Text("Серебро: 500")
                Text("Локация: Лесное озеро")
            }
        }

        Button(
            onClick = { onNavigate(GameScreen.FISHING) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("🎣  ОТПРАВИТЬСЯ НА РЫБАЛКУ") }

        OutlinedButton(
            onClick = { onNavigate(GameScreen.INVENTORY) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("🎒  Инвентарь") }

        OutlinedButton(
            onClick = { onNavigate(GameScreen.SHOP) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("🛒  Магазин") }

        OutlinedButton(
            onClick = { onNavigate(GameScreen.LOCATIONS) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("🗺  Водоёмы") }

        OutlinedButton(
            onClick = { onNavigate(GameScreen.COLLECTION) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("🐟  Коллекция рыб") }
    }
}

@Composable
private fun SimpleScreen(
    title: String,
    description: String,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(description)
        Button(onClick = onBack) { Text("Назад") }
    }
}
