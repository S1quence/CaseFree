// CSS transitions: поезд едет к концу дорожки.
const cssTrain = document.getElementById('cssTrain');
const cssTrainTrack = document.getElementById('cssTrainTrack');
const cssShip = document.getElementById('cssShip');
const cssShipTrack = document.getElementById('cssShipTrack');
const cssRectangle = document.getElementById('cssRectangle');
let shipStep = 0;
let shipHandler = null;

function maxLeft(track, object) {
  return Math.max(0, track.clientWidth - object.getBoundingClientRect().width);
}
function moveCssTrain() {
  cssTrain.style.left = maxLeft(cssTrainTrack, cssTrain) + 'px';
}
function moveCssShip() {
  if (shipHandler) cssShip.removeEventListener('transitionend', shipHandler);
  shipStep = 0;
  const destination = maxLeft(cssShipTrack, cssShip);
  shipHandler = (event) => {
    if (event.propertyName !== 'left') return;
    if (shipStep >= 3) {
      cssShip.removeEventListener('transitionend', shipHandler);
      shipHandler = null;
      return;
    }
    shipStep++;
    cssShip.classList.toggle('back', shipStep % 2 === 0);
    cssShip.style.left = (shipStep % 2 ? 0 : destination) + 'px';
  };
  cssShip.style.left = destination + 'px';
  cssShip.addEventListener('transitionend', shipHandler);
}
function runCssRect() {
  cssRectangle.classList.remove('css-running');
  void cssRectangle.offsetWidth;
  cssRectangle.classList.add('css-running');
}

// JavaScript-анимация через requestAnimationFrame.
const jsObjects = {
  train: { el: document.getElementById('jsTrain'), track: document.getElementById('jsTrainTrack'), duration: 3500, mode: 'once' },
  ship: { el: document.getElementById('jsShip'), track: document.getElementById('jsShipTrack'), duration: 2600, mode: 'alternate' },
  rect: { el: document.getElementById('jsRectangle'), track: document.getElementById('jsRectTrack'), duration: 1800, mode: 'alternate' }
};
const activeAnimations = new Map();

function animateObject(name) {
  const item = jsObjects[name];
  if (!item) return;
  if (activeAnimations.has(name)) cancelAnimationFrame(activeAnimations.get(name));
  const el = item.el;
  const track = item.track;
  const isRect = name === 'rect';
  const width = el.getBoundingClientRect().width;
  const distance = Math.max(0, track.clientWidth - width);
  const start = performance.now();
  const duration = item.duration;
  const repeats = name === 'ship' ? 4 : name === 'rect' ? 4 : 1;

  function frame(now) {
    const elapsed = now - start;
    const cycle = Math.floor(elapsed / duration);
    const fraction = Math.min(1, (elapsed % duration) / duration);
    const forward = cycle % 2 === 0;
    const eased = fraction < .5 ? 2 * fraction * fraction : 1 - Math.pow(-2 * fraction + 2, 2) / 2;
    let progress = forward ? eased : 1 - eased;
    if (name === 'train') progress = 1 - Math.pow(1 - Math.min(1, elapsed / duration), 3);
    el.style.left = (distance * progress) + 'px';
    if (name === 'ship') el.style.transform = forward ? 'scaleX(1)' : 'scaleX(-1)';
    if (isRect) el.style.background = `hsl(${28 + progress * 330}, 70%, 52%)`;

    if (name === 'train' ? elapsed < duration : cycle < repeats) {
      activeAnimations.set(name, requestAnimationFrame(frame));
    } else {
      el.style.left = (name === 'train' ? distance : 0) + 'px';
      activeAnimations.delete(name);
    }
  }
  activeAnimations.set(name, requestAnimationFrame(frame));
}

function resetCss(name) {
  if (name === 'train') cssTrain.style.left = '0px';
  if (name === 'ship') {
    if (shipHandler) cssShip.removeEventListener('transitionend', shipHandler);
    shipHandler = null; cssShip.style.left = '0px'; cssShip.classList.remove('back');
  }
  if (name === 'rect') { cssRectangle.classList.remove('css-running'); cssRectangle.style.left = '0px'; }
}
function resetJs(name) {
  if (activeAnimations.has(name)) cancelAnimationFrame(activeAnimations.get(name));
  activeAnimations.delete(name);
  const el = jsObjects[name].el;
  el.style.left = '0px';
  if (name === 'ship') el.style.transform = 'scaleX(1)';
  if (name === 'rect') el.style.background = '#ed8b28';
}

document.querySelectorAll('[data-css]').forEach(button => button.addEventListener('click', () => {
  const name = button.dataset.css;
  if (name === 'train') moveCssTrain();
  if (name === 'ship') moveCssShip();
  if (name === 'rect') runCssRect();
}));
document.querySelectorAll('[data-reset]').forEach(button => button.addEventListener('click', () => resetCss(button.dataset.reset)));
document.querySelectorAll('[data-js]').forEach(button => button.addEventListener('click', () => animateObject(button.dataset.js)));
document.querySelectorAll('[data-reset-js]').forEach(button => button.addEventListener('click', () => resetJs(button.dataset.resetJs)));
window.addEventListener('resize', () => {
  // При изменении ширины окна объекты остаются в пределах своих дорожек.
  if (cssTrain.style.left) cssTrain.style.left = Math.min(parseFloat(cssTrain.style.left) || 0, maxLeft(cssTrainTrack, cssTrain)) + 'px';
  if (cssShip.style.left) cssShip.style.left = Math.min(parseFloat(cssShip.style.left) || 0, maxLeft(cssShipTrack, cssShip)) + 'px';
});
